const express = require('express');
const app = express();

// load the environment variables

// port 
const SERVERPORT = process.env.PORT;
const routes = require("./routes")

// express app configuration
app.use(express.json());
app.use(express.urlencoded({ extended: false }))

app.use("/api",routes)

app.listen(8888, () => {
    console.log(`Server is running on http://localhost:${8888}`);
});
