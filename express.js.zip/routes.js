const router = require("express").Router()

let formulas = [];
let plans = [];

// POST /formulas - Add a new formula
// Body: { "inputs": { "resource": quantity }, "outputs": { "resource": quantity } }
router.post("/formulas", (req, res) => {
    const formula = req.body;
    formulas.push(formula);
    res.status(201).json({ id: formulas.length - 1, ...formula });
})

// GET /formulas/:formulaId - Get a specific formula by ID
router.get('/formulas/:formulaId', (req, res) => {
    const formulaId = parseInt(req.params.formulaId);
    if (formulas[formulaId]) {
        res.json(formulas[formulaId]);
    } else {
        res.status(404).send('Formula not found');
    }
});

// GET /formulas/:formulaId/plans - List plans containing a specific formula
router.get('/formulas/:formulaId/plans', (req, res) => {
    const formulaId = parseInt(req.params.formulaId);
    const relevantPlans = plans.filter(plan => plan.formulas.includes(formulaId));
    res.json(relevantPlans);
});

// POST /plans - Add a new plan
// Body: { "formulas": [formulaId1, formulaId2] }
router.post('/plans', (req, res) => {
    const plan = req.body;
    plans.push(plan);
    res.status(201).json({ id: plans.length - 1, ...plan });
});

// POST /plans/:planId/formulas - Append a formula to a plan
// Body: { "formulaId": formulaId3 }
router.post('/plans/:planId/formulas', (req, res) => {
    const planId = parseInt(req.params.planId);
    const formulaId = req.body.formulaId;
    if (plans[planId]) {
        plans[planId].formulas.push(formulaId);
        res.json(plans[planId]);
    } else {
        res.status(404).send('Plan not found');
    }
});

// PUT /plans/:planId/formulas/:sequenceNumber - Replace a formula in a plan
// Body: { "formulaId": newFormulaId }
router.put('/plans/:planId/formulas/:sequenceNumber', (req, res) => {
    const planId = parseInt(req.params.planId);
    const sequenceNumber = parseInt(req.params.sequenceNumber);
    const formulaId = req.body.formulaId;
    if (plans[planId] && plans[planId].formulas[sequenceNumber]) {
        plans[planId].formulas[sequenceNumber] = formulaId;
        res.json(plans[planId]);
    } else {
        res.status(404).send('Plan or formula sequence not found');
    }
});

// GET /plans/:planId/formulas - List all formulas in a plan
router.get('/plans/:planId/formulas', (req, res) => {
    const planId = parseInt(req.params.planId);
    if (plans[planId]) {
        res.json(plans[planId].formulas);
    } else {
        res.status(404).send('Plan not found');
    }
});

// DELETE /plans/:planId - Delete a plan
router.delete('/plans/:planId', (req, res) => {
    const planId = parseInt(req.params.planId);
    if (plans[planId]) {
        plans.splice(planId, 1);
        res.status(204).send();
    } else {
        res.status(404).send('Plan not found');
    }
});

module.exports = router